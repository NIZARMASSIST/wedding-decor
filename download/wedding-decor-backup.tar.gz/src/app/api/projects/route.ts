import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET - جلب جميع المشاريع
export async function GET(request: NextRequest) {
  try {
    console.log('Fetching projects...')
    
    const searchParams = request.nextUrl.searchParams
    const id = searchParams.get('id')
    
    if (id) {
      const project = await db.project.findUnique({
        where: { id },
        include: {
          items: {
            include: {
              stages: {
                include: {
                  department: true,
                  checklist: true
                }
              }
            }
          }
        }
      })
      return NextResponse.json(project)
    }
    
    const projects = await db.project.findMany({
      include: {
        items: {
          include: {
            stages: {
              include: {
                department: true
              }
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    console.log(`Found ${projects.length} projects`)
    
    return NextResponse.json(projects)
  } catch (error) {
    console.error('Error fetching projects:', error)
    return NextResponse.json({ 
      error: 'Failed to fetch projects',
      details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : 'Unknown error') : undefined
    }, { status: 500 })
  }
}

// POST - إنشاء مشروع جديد
export async function POST(request: NextRequest) {
  try {
    console.log('Creating new project...')
    
    const data = await request.json()
    console.log('Project data:', data)
    
    // التحقق من وجود تاريخ المشروع على الأقل
    if (!data.projectDate && !data.name?.trim()) {
      return NextResponse.json({ 
        error: 'Project date or name is required' 
      }, { status: 400 })
    }
    
    // إنشاء اسم المشروع من التاريخ تلقائياً
    let projectName = data.name?.trim() || ''
    if (!projectName && data.projectDate) {
      const d = new Date(data.projectDate)
      projectName = `Project ${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
    }
    if (!projectName) {
      projectName = `Project ${new Date().toISOString().split('T')[0]}`
    }

    const project = await db.project.create({
      data: {
        name: projectName,
        nameAr: data.nameAr?.trim() || null,
        projectDate: data.projectDate ? new Date(data.projectDate) : null,
        location: data.location?.trim() || null,
        recipient: data.recipient?.trim() || null,
        executiveManager: data.executiveManager?.trim() || null,
        clientName: data.clientName?.trim() || null,
        description: data.description?.trim() || null,
        image: data.image || null,
        status: data.status || 'active',
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        deadline: data.deadline ? new Date(data.deadline) : null,
        notes: data.notes?.trim() || null,
        notesAuthor: data.notesAuthor?.trim() || null
      }
    })
    
    console.log('Project created:', project.id)
    
    return NextResponse.json(project)
  } catch (error) {
    console.error('Error creating project:', error)
    return NextResponse.json({ 
      error: 'Failed to create project',
      details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : 'Unknown error') : undefined
    }, { status: 500 })
  }
}

// PUT - تحديث مشروع
export async function PUT(request: NextRequest) {
  try {
    const data = await request.json()
    
    if (!data.id) {
      return NextResponse.json({ error: 'Project ID is required' }, { status: 400 })
    }
    
    const project = await db.project.update({
      where: { id: data.id },
      data: {
        name: data.name,
        nameAr: data.nameAr,
        projectDate: data.projectDate ? new Date(data.projectDate) : null,
        location: data.location,
        recipient: data.recipient,
        executiveManager: data.executiveManager,
        clientName: data.clientName,
        description: data.description,
        image: data.image,
        status: data.status,
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        deadline: data.deadline ? new Date(data.deadline) : null,
        notes: data.notes,
        notesAuthor: data.notesAuthor
      }
    })
    
    return NextResponse.json(project)
  } catch (error) {
    console.error('Error updating project:', error)
    return NextResponse.json({ 
      error: 'Failed to update project',
      details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : 'Unknown error') : undefined
    }, { status: 500 })
  }
}

// DELETE - حذف مشروع
export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const id = searchParams.get('id')
    
    if (!id) {
      return NextResponse.json({ error: 'Project ID is required' }, { status: 400 })
    }
    
    // حذف جميع العناصر المرتبطة بالمشروع أولاً
    await db.productionItem.deleteMany({
      where: { projectId: id }
    })
    
    // حذف المشروع
    await db.project.delete({
      where: { id }
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting project:', error)
    return NextResponse.json({ 
      error: 'Failed to delete project',
      details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : 'Unknown error') : undefined
    }, { status: 500 })
  }
}
